@extends("layout/layout")

@section("content")
    <section>
        <div class="main-container">
            <div class="main-contents">
                <div class="excel-upload-container">
                    <h4>Upload Excel File </h4>
                    <div class="form-container">
                        @if(count($errors) > 0)
                            @foreach ($errors->all() as $error)
                                <p style="color: red;">{{$error}}</p>
                            @endforeach
                        @endif

                        @if($message = Session::get("Success"))
                        <p style="color: red;">{{$message}}</p>
                        @endif
                        <form class="form" action="/index" method="post" enctype="multipart/form-data">
                            {{csrf_field()}}
                            <fieldset class="form-group">
                                <input type="file" name="select-file"/>
                            </fieldset>
                            <button class="btn btn-primary" type="submit">Upload</button>
                        </form>
                    </div>
                    <br>
                    <div class="imported-data">
                        <table>
                            <thead>
                                    <tr>
                                        <th>Email Address</th>
                                        <th>Name</th>
                                        <th>City</th>
                                        <th>Zip</th>
                                        <th>Number</th>
                                        <th>Street</th>
                                    </tr>
                            </thead>
                            <tbody>
                                {{-- @foreach ($collection as $item)
                                    <tr>
                                        <td>{{$item->Email}}</td>
                                        <td>{{$item->Name}}</td>
                                        <td>{{$item->City}}</td>
                                        <td>{{$item->Zip}}</td>
                                        <td>{{$item->Number}}</td>
                                        <td>{{$item->Street}}</td>
                                    </tr>
                                @endforeach --}}
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </section>
@endsection