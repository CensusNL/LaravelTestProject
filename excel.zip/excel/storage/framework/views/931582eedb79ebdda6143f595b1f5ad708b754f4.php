<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title><?php echo e(config("app.name", "Import Excel File")); ?></title>

        <!-- Fonts -->
       
        <!-- Styles -->
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset("css/app.css")); ?>"/>
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset("css/main.css")); ?>"/>
        <!-- Styles -->

        <!-- scripts -->
        <script type="text/javascript" src="<?php echo e(asset("js/main.js")); ?>"></script>
        <script type="text/javascript" src="<?php echo e(asset("js/jquery.js")); ?>"></script>
        <!-- scripts -->
    </head>
    <body>
        <header>
            <div class="header-container">
                <div class="header-content-container">
                    <div class="header-content">
                        <div class="header-logo">
                            <h4>Import Excel File</h4>
                        </div>   
                        <div class="header-mobile-menu">
                            <div class="bar barOne"></div>
                            <div class="bar barTwo"></div>
                            <div class="bar barThree"></div>
                        </div>   
                        <div class="header-main-navigation">
                            <a href="/">Home</a>
                            <a href="/gallery">Gallery</a>
                            <a href="/services">Services</a>
                        </div>  
                    </div>
                </div>
            </div>
        </header>
        <div>
            <?php echo $__env->yieldContent("content"); ?>
        </div>
    </body>
</html>
<?php /**PATH C:\xampp\htdocs\projects\excel\resources\views/layout/layout.blade.php ENDPATH**/ ?>