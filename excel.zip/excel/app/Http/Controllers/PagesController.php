<?php

namespace App\Http\Controllers;

use DB;
use Mail;
use Illuminate\Http\Request;

class PagesController extends Controller
{
    //
    public function index()
    {
        $collection = DB::table("users")->get();
        return view("pages/index")->with("collection", $collection);
    }

    public function importExcel(Request $request)
    {
        $this->validate($request, [
            "select-file" => "required|mimes:xls,xlsx"
        ]);

        $actualPath = $request->file("select-file")->getRealPath();
        $collection = Excel::load($actualPath)->get();

        if ($collection->count > 0) {
            foreach ($collection->toArray as $key => $item) {
                $insertData = array(
                    "Email" => $item["Email"],
                    "Name" => $item["Name"],
                    "City" => $item["City"],
                    "Zip" => $item["Zip"],
                    "Number" => $item["Number"],
                    "Street" => $item["Street"]
                );

                Mail::send(['user' => $item], function ($m) use ($item) {
                    $m->from('hello@dataimport.com', 'This is a general invitation');

                    $m->to($item["Email"], $item["Name"])->subject('Invitation!');
                });
            }
        }

        if (!empty($insertData)) {
            DB::table("users")->insert($insertData);
        }

        return back()->with("Success", "Data Imported Successfully!");
    }
}
