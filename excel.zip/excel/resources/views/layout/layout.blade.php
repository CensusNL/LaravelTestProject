<!doctype html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>{{config("app.name", "Import Excel File")}}</title>

        <!-- Fonts -->
       
        <!-- Styles -->
        <link rel="stylesheet" type="text/css" href="{{asset("css/app.css")}}"/>
        <link rel="stylesheet" type="text/css" href="{{asset("css/main.css")}}"/>
        <!-- Styles -->

        <!-- scripts -->
        <script type="text/javascript" src="{{asset("js/main.js")}}"></script>
        <script type="text/javascript" src="{{asset("js/jquery.js")}}"></script>
        <!-- scripts -->
    </head>
    <body>
        <header>
            <div class="header-container">
                <div class="header-content-container">
                    <div class="header-content">
                        <div class="header-logo">
                            <h4>Import Excel File</h4>
                        </div>   
                        <div class="header-mobile-menu">
                            <div class="bar barOne"></div>
                            <div class="bar barTwo"></div>
                            <div class="bar barThree"></div>
                        </div>   
                        <div class="header-main-navigation">
                            <a href="/">Home</a>
                            <a href="/gallery">Gallery</a>
                            <a href="/services">Services</a>
                        </div>  
                    </div>
                </div>
            </div>
        </header>
        <div>
            @yield("content")
        </div>
    </body>
</html>
