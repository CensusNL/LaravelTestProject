<?php $__env->startSection("content"); ?>
    <section>
        <div class="main-container">
            <div class="main-contents">
                <div class="excel-upload-container">
                    <h4>Upload Excel File </h4>
                    <div class="form-container">
                        <?php if(count($errors) > 0): ?>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <p style="color: red;"><?php echo e($error); ?></p>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>

                        <?php if($message = Session::get("Success")): ?>
                        <p style="color: red;"><?php echo e($message); ?></p>
                        <?php endif; ?>
                        <form class="form" action="/index" method="post" enctype="multipart/form-data">
                            <?php echo e(csrf_field()); ?>

                            <fieldset class="form-group">
                                <input type="file" name="select-file"/>
                            </fieldset>
                            <button class="btn btn-primary" type="submit">Upload</button>
                        </form>
                    </div>
                    <br>
                    <div class="imported-data">
                        <table>
                            <thead>
                                    <tr>
                                        <th>Email Address</th>
                                        <th>Name</th>
                                        <th>City</th>
                                        <th>Zip</th>
                                        <th>Number</th>
                                        <th>Street</th>
                                    </tr>
                            </thead>
                            <tbody>
                                
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layout/layout", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\projects\excel\resources\views/pages/index.blade.php ENDPATH**/ ?>